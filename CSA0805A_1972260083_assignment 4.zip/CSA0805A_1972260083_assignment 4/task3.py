class InvalidRecord(Exception):
    pass


def parse_line(line):
    parts = line.strip().split(",")

    if len(parts) != 3:
        raise InvalidRecord("Expected 3 fields")

    reg, date, status = parts

    if status not in ["P", "A"]:
        raise InvalidRecord("Invalid status")

    return reg, date, status


def summarise(filename):
    present = 0
    absent = 0
    errors = []

    try:
        with open(filename, "r") as file:
            for number, line in enumerate(file, 1):
                try:
                    reg, date, status = parse_line(line)

                    if status == "P":
                        present += 1
                    else:
                        absent += 1

                except InvalidRecord as error:
                    errors.append((number, str(error)))

    except FileNotFoundError:
        print("File not found")

    return present, absent, errors


print(summarise("attendance.csv"))