def read_records(filename):
    with open(filename, "r") as file:
        return file.readlines()

def percentage(present, total):
    if total == 0:
        return 0

    return (present / total) * 100

def write_report(filename, data):
    with open(filename, "w") as file:
        file.write(data)


result = percentage(18, 20)

print("Attendance:", result, "%")

write_report("report.txt", str(result))