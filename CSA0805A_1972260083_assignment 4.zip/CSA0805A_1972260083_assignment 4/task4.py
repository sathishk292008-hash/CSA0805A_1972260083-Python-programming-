def save_returns(books):
    with open("returns.log", "a") as file:
        for book in books:
            file.write(book + "\n")


def process(filename):
    try:
        with open(filename, "r") as file:
            books = file.read().splitlines()

        save_returns(books)

    except FileNotFoundError:
        with open("errors.log", "a") as file:
            file.write(filename + " not found\n")


process("day1.txt")
process("day2.txt")
process("day3.txt")

print("Book records saved")