from pathlib import Path

seen = set()
students = []
events = {}
errors = []

def valid_email(email):
    return email.count("@") == 1 and "." in email.split("@")[1]


for path in Path("department_files").glob("*.txt"):

    try:
        with open(path, "r") as file:

            for number, line in enumerate(file, 1):

                try:
                    parts = line.strip().split(",")

                    if len(parts) != 5:
                        raise ValueError("Invalid fields")

                    reg, name, dept, email, chosen = parts

                    if not valid_email(email):
                        raise ValueError("Invalid email")

                    if reg in seen:
                        raise ValueError("Duplicate registration")

                    seen.add(reg)
                    students.append(line.strip())

                    for event in chosen.split(";"):
                        event = event.strip()

                        if event:
                            events.setdefault(event, []).append(reg)

                except ValueError as error:
                    errors.append(f"{path.name}, Line {number}: {error}")

    except FileNotFoundError:
        errors.append(path.name + " not found")


# Master list
with open("master_list.txt", "w") as file:
    for student in students:
        file.write(student + "\n")


# Event-wise reports
for event, registers in events.items():
    filename = event.replace(" ", "_") + ".txt"

    with open(filename, "w") as file:
        for reg in registers:
            file.write(reg + "\n")


# Summary report
with open("summary.txt", "w") as file:
    file.write("Total Registrations: " + str(len(students)) + "\n")
    file.write("Total Events: " + str(len(events)))


# Error log
with open("error.log", "w") as file:
    for error in errors:
        file.write(error + "\n")


print("Fest Registration Completed")