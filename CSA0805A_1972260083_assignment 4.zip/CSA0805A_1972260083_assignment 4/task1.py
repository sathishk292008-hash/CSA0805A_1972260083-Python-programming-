from decimal import Decimal

def process_file(filename):
    total = Decimal("0.00")
    rejected = []

    try:
        with open(filename, "r") as file:
            for line_no, line in enumerate(file, 1):
                try:
                    parts = line.strip().split(",")

                    if len(parts) != 3:
                        raise ValueError("Invalid record")

                    reg, name, amount = parts
                    total += Decimal(amount)

                    print(reg, name, amount)

                except ValueError:
                    rejected.append(line_no)

        print("Total Amount:", total)
        print("Rejected Lines:", rejected)

    except FileNotFoundError:
        print("File not found")

process_file("mess_oct.txt")