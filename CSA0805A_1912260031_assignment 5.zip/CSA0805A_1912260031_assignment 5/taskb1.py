import csv

data = """station,date,pm25
Adyar,2026-10-01,48
Adyar,2026-10-02,NA
Guindy,2026-10-01,95
Guindy,2026-10-02,-5
Guindy,2026-10-03,121
"""

rows = []

reader = csv.DictReader(data.splitlines())

for row in reader:

    value = row["pm25"].strip()

    if value == "" or value == "NA":
        continue

    try:
        pm25 = float(value)
    except ValueError:
        continue

    if pm25 < 0 or pm25 > 999:
        continue

    rows.append(pm25)

print("Cleaned Data:", rows)

minimum = min(rows)
maximum = max(rows)

normalised = []

for value in rows:
    result = (value - minimum) / (maximum - minimum)
    normalised.append(round(result, 3))

print("Normalised Data:", normalised)