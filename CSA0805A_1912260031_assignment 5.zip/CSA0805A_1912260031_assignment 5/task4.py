import logging
import time

logging.basicConfig(filename="cleaning.log",level=logging.INFO)

start = time.perf_counter()
numbers = [10, 20, 30, 40, 50]
total = sum(numbers)

logging.info("Calculation completed")

end = time.perf_counter()

print("Total:", total)
print("Execution Time:", end - start)