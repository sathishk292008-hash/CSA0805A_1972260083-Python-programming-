def clean_data(values):
    result = []

    for value in values:
        if value >= 0 and value <= 999:
            result.append(value)

    return result


def normalise(values):
    if not values:
        return []

    minimum = min(values)
    maximum = max(values)

    if maximum == minimum:
        return [0 for value in values]

    result = []

    for value in values:
        new_value = (value - minimum) / (maximum - minimum)
        result.append(round(new_value, 3))

    return result


data = [48, 95, -5, 121, 1200]

cleaned = clean_data(data)
print("Cleaned Data:", cleaned)

normalised = normalise(cleaned)
print("Normalised Data:", normalised)