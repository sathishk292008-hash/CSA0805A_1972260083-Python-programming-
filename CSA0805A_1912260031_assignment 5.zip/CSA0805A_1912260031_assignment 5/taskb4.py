complaints = [
    "Air quality is good",
    "The area is dirty",
    "Air pollution is bad",
    "The service is helpful",
    "Smoke pollution is high"
]

positive = ["good", "helpful", "clean"]
negative = ["dirty", "bad", "smoke"]

positive_count = 0
negative_count = 0
neutral_count = 0

for complaint in complaints:

    words = complaint.lower().split()

    score = 0

    for word in words:
        if word in positive:
            score += 1
        elif word in negative:
            score -= 1

    if score > 0:
        positive_count += 1
        result = "Positive"

    elif score < 0:
        negative_count += 1
        result = "Negative"

    else:
        neutral_count += 1
        result = "Neutral"

    print(complaint, ":", result)


print("\nFINAL SUMMARY")
print("Positive:", positive_count)
print("Negative:", negative_count)
print("Neutral:", neutral_count)