import sqlite3

con = sqlite3.connect("air_quality.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS stations (
    station_id INTEGER PRIMARY KEY,
    station_name TEXT UNIQUE,
    temperature_unit_source TEXT
)
""")

cur.execute("""CREATE TABLE IF NOT EXISTS readings (reading_id INTEGER PRIMARY KEY,
    station_id INTEGER,
    reading_date TEXT,reading_hour INTEGER,
    pm25 REAL,pm10 REAL,no2 REAL,
    temperature_c REAL,
    FOREIGN KEY (station_id) REFERENCES stations(station_id))""")

cur.execute("""INSERT OR IGNORE INTO stations
VALUES (1, 'Adyar', 'C')""")

con.commit()
con.close()

print("Database created successfully")