import sqlite3

con = sqlite3.connect(":memory:")
cur = con.cursor()

cur.execute("""
CREATE TABLE readings (
    station TEXT,
    pm25 REAL
)
""")

data = [
    ("Adyar", 48),
    ("Guindy", 95),
    ("Adyar", 60)
]

cur.executemany(
    "INSERT INTO readings VALUES (?, ?)",
    data
)

con.commit()

station = input("Enter station name: ")

cur.execute(
    "SELECT AVG(pm25) FROM readings WHERE station = ?",
    (station,)
)

result = cur.fetchone()

print("Average PM2.5:", result[0])

con.close()