import matplotlib.pyplot as plt

stations = ["Adyar", "Guindy", "Velachery"]
pm25 = [48, 95, 70]

average = sum(pm25) / len(pm25)

print("Average PM2.5:", average)

plt.bar(stations, pm25)
plt.title("Air Quality Monitoring")
plt.xlabel("Stations")
plt.ylabel("PM2.5 Level")
plt.show()