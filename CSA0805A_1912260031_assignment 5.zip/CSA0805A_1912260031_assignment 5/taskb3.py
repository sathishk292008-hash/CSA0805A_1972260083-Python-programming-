data = [48, 95, 70, 60, 80]

total = 0

for value in data:
    total += value

average = total / len(data)

print("Loop Average:", average)