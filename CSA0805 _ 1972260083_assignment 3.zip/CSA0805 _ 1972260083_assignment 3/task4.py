students_a = {"Arun", "Bala", "Chitra", "Divya"}
students_b = {"Bala", "Divya", "Ezhil"}

common = students_a & students_b
print("Students in both Electives:", common)

only_a = students_a - students_b
print("Students only in Elective A:", only_a)

only_b = students_b - students_a
print("Students only in Elective B:", only_b)

print("All students in Elective A and B:", students_a.union(students_b))