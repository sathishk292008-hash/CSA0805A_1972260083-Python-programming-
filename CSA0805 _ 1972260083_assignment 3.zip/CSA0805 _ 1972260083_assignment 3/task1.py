rainfall = [12, 18, 10, 25, 20, 15, 30]

print("All rainfall values:", rainfall)
print("First 3 days:", rainfall[:3])
print("Last 3 days:", rainfall[-3:])
print("Total rainfall:", sum(rainfall))