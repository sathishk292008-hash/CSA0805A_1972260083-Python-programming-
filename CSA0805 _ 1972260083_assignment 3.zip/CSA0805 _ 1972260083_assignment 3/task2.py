student = ("Nithin", 17, "ECE")
student_copy = tuple(student)

print("Original tuple:", student)
print("Copied tuple:", student_copy)
print("Student name:", student[0])
print("Student age:", student[1])
print("Student branch:", student[2])