timetable = {
    "Chennai": {"departure": "08:00", "arrival": "12:00"},
    "Bengaluru": {"departure": "09:30", "arrival": "14:00"}
}

for station, times in timetable.items():
    print(station)
    print("Departure:", times["departure"])
    print("Arrival:", times["arrival"])